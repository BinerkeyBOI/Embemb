import shutil


with open("./assets/Command Folder.embsetting") as folder:
    mainFolder = folder.read()
try:
    with open(mainFolder + "startup.txt") as file:
        exec(file.read())
        file.close()
except:
    print("failed to execute startup command")

def line():
    UserCommand = input(">")
    try:
        with open(mainFolder + UserCommand + ".txt") as command:
            exec(command.read())
            line()
            command.close()
    except:
        print("Command doesn't exist or doesn't work, to look at commands use help, or use custom commands.")
        line()
        command.close()
def settingLine():
    print("type in mainFolder to change the main commands folder.")
    print("type read to read your settings.")
    print("type line to change the line type.")
    UserCommand = input("settings>")
    if UserCommand == "mainFolder":
        print("")
        print("Please use python directory such as C:/... Not backslashes also finish with a final slash")
        UserFolder = input("folder}")
        with open("./assets/Command Folder.embsetting", "w") as folder:
            folder.write(UserFolder)
    elif UserCommand == "read":
        print("")
        with open("./assets/Command Folder.embsetting") as folder:
            print("Commands Folder - " + folder.read())
        with open("./assets/startupline.embsetting") as lin:
            print("Line type startup - " + lin.read())
    elif UserCommand == "line":
        print("")
        print("Put either default or special")
        UserLine = input("type)")
        with open("./assets/startupline.embsetting", "w") as lin:
            lin.write(UserLine)
    print("Changes will appear once app gets restarted.")
    line()

def specialLine():
    UserCommand = input("}.")
    try:
        with open("./Special Commands/" + UserCommand + ".py") as command:
            exec(command.read())
        specialLine()
    except:
        print("Error in execution, either it doesn't exist or error in code.")
        specialLine()
        




with open("./assets/startupline.embsetting") as file:
    mainline = file.read()
if mainline == "default":
    line()
elif mainline == "special":
    specialLine()